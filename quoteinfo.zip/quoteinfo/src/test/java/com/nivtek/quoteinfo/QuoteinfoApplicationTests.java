package com.nivtek.quoteinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
