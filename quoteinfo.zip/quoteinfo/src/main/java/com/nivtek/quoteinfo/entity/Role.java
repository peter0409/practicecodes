package com.nivtek.quoteinfo.entity;

public enum Role {
	 USER,ADMIN

}
