package com.nivtek.hibernate.model;

public enum OrderStatus {

	  BILLING_FAILED,
	  COMPLETE
	 
}
